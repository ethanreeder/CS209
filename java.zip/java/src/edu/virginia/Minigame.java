package edu.virginia.engine.display;
import java.awt.*;
import java.util.ArrayList;

import edu.virginia.engine.display.DisplayObject;


public class Minigame extends DisplayObject {
    private ArrayList<Dial> dialList;
    private int onDial;

}